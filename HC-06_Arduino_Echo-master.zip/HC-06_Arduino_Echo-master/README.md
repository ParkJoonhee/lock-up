HC-06 Arduino Echo
==================

Android gets an echo message from Arduino by HC-06 and Bluetooth. 

Very simple android app code.

Eclipse for Android project.<br/>
Arduino source file : 'Arduino src' directory<br/>
Play store : <a href="https://play.google.com/store/apps/details?id=kr.re.Dev.BluetoothEcho"> https://play.google.com/store/apps/details?id=kr.re.Dev.BluetoothEcho</a>

![screenshot](http://cfile8.uf.tistory.com/image/21381E3653A62953108254)


Blog : http://Dev.re.kr
